<div class="info">
    <h3>VEHICLE DETAILS:-</h3>
    <div class="left">
        <label for name><font size='5'>Vehicle Number:</label>
        <?php echo "<font size='5'> $vchno"; ?><br><br>
        <label for vchno><font size='5'>Vehicle Fuel Type:</label>
        <?php echo $ftype; ?>
    </div>

    <div class="right">
        <label for add><font size='5'>Vehicle Manufacturer:</label>
        <?php echo "<font size='5'> $comp"; ?><br><br>
        <label for phno><font size='5'>Vehicle Model:</label>
        <?php echo $vmodel; ?>
    </div>
    <br><br><br><br><br>
    <form action="upcarinfo.php" method="POST">
        <input type="submit" value="Update Vehicle Info" style="padding:5px 5px;width: 500x;">
    </form>
</div>