<?php
    session_start();
    include('mainlog.php');
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="mainpage.css">
    <title>Login Page</title>
</head>
<body bgcolor="#b3b3cc">
    
    <div class="container">
        <?php include('error.php') ?>
        <br>
        <br>
        <div class="innerContainer">
            <img src="userImg.png" id="userImg" width="100px" height="100px">
            <div class="inputform">
                <form action="login.php" method="POST">
                    <label for username>Username</label><br>
                    <input type="text" name="username" placeholder="Enter Username...." required><br><br>
                    <label for password>Password</label><br>
                    <input type="password" name="password" placeholder="Enter Password...." required><br><br><br>
                    <input type="submit" name="log" value="Log In"><br><br>
                </form>
            </div>
        </div>
    </div>

</body>
</html>