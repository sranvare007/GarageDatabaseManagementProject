<?php
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$query3 = "SELECT * FROM temp";
$result3 = mysqli_query($conn,$query3);

$query4 = "SELECT SUM(totprice) + SUM(servcg) FROM temp";
$result4 = mysqli_query($conn,$query4);
$row = mysqli_fetch_assoc($result4);
$resu = $row['SUM(totprice) + SUM(servcg)'];

?>