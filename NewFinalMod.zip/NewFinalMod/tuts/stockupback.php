<?php
$error = array();

$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

$query = "SELECT * FROM pinfo";
$result = mysqli_query($conn,$query);

//To update existing Part Info
if(isset($_POST['upexis']))
{
    
    $qty = $_POST['qty'];
    $price = $_POST['price'];
    $pname = strtoupper($_POST['pname']);
    $supplier = strtoupper($_POST['supplier']);

    $query3 = "SELECT * FROM pinfo WHERE pname='$pname'";
    $result3 = mysqli_query($conn,$query3);
    $row = mysqli_fetch_assoc($result);

    if(empty($pname) || empty($qty))
    {
        array_push($error,"Partname and quantity are required while Updation!");
    }
    if(empty($price))
    {
        $price = $row['price'];
    }
    if(empty($supplier))
    {
        $supplier = $row['supplier'];
    }
    if(count($error) == 0)
    {
        $query1 = "UPDATE pinfo SET qty=qty+'$qty', price='$price', supplier='$supplier' WHERE pname='$pname'";
        $result1 = mysqli_query($conn,$query1);
    }
}




//For New Part Data to be added
if(isset($_POST['upnew']))
{
    $qty = $_POST['qty'];
    $price = $_POST['price'];
    $pname = strtoupper($_POST['pname']);
    $supplier = strtoupper($_POST['supplier']);

    if(empty($pname) || empty($price) || empty($qty) || empty($supplier))
    {
        array_push($error,"All Fields are required while adding new part Info!");
    }
    if(count($error) == 0)
    {
        $query2 = "INSERT INTO pinfo (pname,qty,price,supplier) VALUES ('$pname','$qty','$price','$supplier')";
        $result2 = mysqli_query($conn,$query2); 
    }
}

?>