<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

if(!isset($_SESSION['vchno']))
{
    header('location: Ulog.php');
}

if(isset($_POST['sub']))
{
    $type = strtoupper($_POST['servtype']);
    if(empty($type))
    {
        array_push($error,"Service field cannot be Empty");
    }
    if(count($error) == 0)
    {
        $_SESSION['type'] = $type;
        if($type == 'FULL' ||$type == 'PART')
        {
            $query1 = "TRUNCATE TABLE temp";
            mysqli_query($conn,$query1);
            header('location: partrep.php');
        }
        else if($type == 'FIT' ||$type == 'WASH')
        {
            $query2 = "TRUNCATE TABLE temp_serv";
            mysqli_query($conn,$query2);
            header('location: nopartrep.php');
        }
    }
}





?>