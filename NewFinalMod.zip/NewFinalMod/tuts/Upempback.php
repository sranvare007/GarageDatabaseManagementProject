<?php

$conn = mysqli_connect('localhost','root','');
$error = array();
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$query = "SELECT * FROM emp_data";

$result = mysqli_query($conn,$query);

if(isset($_POST['update']))
{

    $emp_id = $_POST['emp_id'];
    $name = strtoupper($_POST['name']);
    $phno = $_POST['phno'];
    $addr = strtoupper($_POST['addr']);
    $expr = $_POST['exp'];
    $doj = $_POST['doj'];
    $age = $_POST['age'];
    $sal = $_POST['sal'];
    $tid = $_POST['id'];

    $query1 = "SELECT * FROM emp_data WHERE emp_id='$emp_id'";

    $result1 = mysqli_query($conn,$query1);
    $row = mysqli_fetch_assoc($result1);

    
    if((empty($name) && empty($phno) && empty($addr) && empty($expr) && empty($doj) && empty($age) && empty($sal)))
    {
        array_push($error,"All fields cannot be empty!");
    }
    if(empty($tid))
    {
        array_push($error,"Id cannot be Empty");
    }

    if(empty($name))
    {
        $name = $row['name'];
    }
    if(empty($phno))
    {
        $phno = $row['phno'];
    }
    if(empty($addr))
    {
        $addr = $row['addr'];
    }
    if(empty($expr))
    {
        $expr = $row['expr'];
    }
    if(empty($doj))
    {
        $doj = $row['doj'];
    }
    if(empty($age))
    {
        $age = $row['age'];
    }
    if(empty($sal))
    {
        $sal = $row['sal'];
    }
    if(count($error) == 0)
    {
        $query2 = "UPDATE emp_data SET name='$name',phno='$phno',addr='$addr',expr='$expr',doj='$doj',age='$age',sal='$sal' WHERE emp_id='$tid'";
        mysqli_query($conn,$query2);
        header('location: Emp.php');
    }
}
if(!empty($_POST['emp_id']))
{
    $emp_id = $_POST['emp_id'];
    $query3 = "SELECT * FROM emp_data WHERE emp_id='$emp_id'";
    $result3 = mysqli_query($conn,$query3);
    $row3 = mysqli_fetch_assoc($result3);
}
else
{
    $row3=array();
    $row3['name']="";
    $row3['phno']="";
    $row3['addr']="";
    $row3['expr']="";
    $row3['sal']="";
    $row3['doj']="";
    $row3['age']="";

}




?>