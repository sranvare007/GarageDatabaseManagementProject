<?php
session_start();
include('Upempback.php');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style1.css">
        <style>

        label
        {
            color:black;
        }
        select
        {
            width: 100%;
            padding: 14px;
            box-sizing: border-box;
            border-radius: 4px;
            border: 1px solid black;
            margin: 12px 8px;
        }

        .info
        {
            /* background-color: red; */
            margin-top: 20px;
            text-align: center;
            padding-top: 80px;
            padding-right: 16px;
            padding-bottom: 180px;
            background-color: #007399; 
            border-radius: 10px;
            /* padding: 200px 100px; */
        }
        
        </style>
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br>
        <br><br>

        <div class="info">
        <?php include('error.php') ?>
            <h1>Update Employee Info:</h1>
            <br><br><br>
            <form action="" method="POST">
                
                <label for emp_id>Emplyee Id to be Updated:</label>
                <select name="emp_id" onchange='this.form.submit()'>
                        <option value="">---  None  ---</option>
                        <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
                                $emp_id = $row['emp_id'];
                                echo '<option value="' . $emp_id . '">' . $emp_id . '</option>';
                            }
                        ?>
                </select>
                <label for tid>Employee Id:</label><br>
                <input type="number" name="id" value="<?php echo $row3['emp_id']; ?>" readonly="readonly"><br><br>
                <label for name>New Employee Name:</label><br>
                <input type="text" name="name" value="<?php echo $row3['name']; ?>"><br><br>
                <label for phno>New Phone Number:</label><br>
                <input type="number" name="phno" value="<?php echo $row3['phno']; ?>"><br><br>
                <label for addr>New Address:</label><br>
                <input type="text" name="addr" value="<?php echo $row3['addr']; ?>"><br><br>
                <label for exp>New Work Experience:</label><br>
                <input type="number" name="exp" value="<?php echo $row3['expr']; ?>"><br><br>

                <label for sal>New Salary:</label><br>
                <input type="number" name="sal" value="<?php echo $row3['sal']; ?>"><br><br>

                <label for doj>New Date of Joining:</label><br>
                <input type="date" name="doj" value="<?php echo $row3['doj']; ?>"><br><br>
                <label for age>New Age:</label><br>
                <input type="number" name="age" value="<?php echo $row3['age'];?>"><br><br>
                <input type="submit" name="update" value="Update Info">
            </form>
        </div>
        
    </body>
</html>