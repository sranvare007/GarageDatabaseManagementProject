<?php
session_start();
include('serviceback.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style12.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br>

        <div class="info">
            <?php include('error.php') ?>
            <form action="" method="POST">
                    <font size='5px'>
                    <p>Service Type:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                        <select name="servtype" id="servtype">
                            <option value=""></option>
                            <option value="full">Full Servicing</option>
                            <option value="part">Part Replacement</option>
                            <option value="fit">Fitting</option>
                            <option value="wash">Washing</option>
                        </select>
                    </p>
                    <input type="submit" value="Next" name="sub">
            </form>
        </div>
    </body>
</html>