<?php
session_start();
include('dataret.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Vehicle Service Details</title>
        <link rel="stylesheet" type="text/css" href="style/style12.css">


    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Acc.php">Accounts Info</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
        </ul>

        <br><br><br><br><br>
        

        <div class="info">
            <form action="" method="POST">
                <font size='5px'>
                <p>Service Type:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                    <select id="mySelect" name="servtype" id="servtype" onchange="func()">
                        <option value=""></option>
                        <option value="full">Full Servicing</option>
                        <option value="part">Part Replacement</option>
                        <option value="fit">Fitting</option>
                        <option value="wash">Washing</option>
                    </select>
                </p>
                <div class="part">
                    <p>Parts Used:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
                        <select name="pname" id="pname">
                            <option value=""></option>
                            <?php 
                                while($row = mysqli_fetch_assoc($result))
                                {
                                    $pname = $row['pname'];
                                    echo '<option value="' . $pname . '">' . $pname . '</option>';
                                }
                            ?>
                        </select>
                    </p>
                    <p>Quantity Used:&emsp;&emsp;&emsp;&emsp;&emsp;
                    <input type="number" name="qty" id ="qty" placeholder="Enter Quantity......">
                    </p>
                    <br>
                    <input type="submit" value="Add" id="Add" name="Add">
                    <br><br>
                    <table class="parts" name="parts"></table>
                    <input type="submit" value="submit" name="submit">
                </div>
                <p>Total Price:</p>

            </form>
         </div>








    <script src="part.js"></script>
    </body>
</html>