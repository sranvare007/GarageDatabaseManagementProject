<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['vchno']))
{
    header('location: Ulog.php');
}
$vchno = $_SESSION['vchno'];

$query = "SELECT * FROM pinfo";
$result = mysqli_query($conn,$query);


if(isset($_POST['submit']))
{
    // $pname = $_POST['pname'];
    // $qty = $_POST['qty'];
    // $query2 = "SELECT * FROM pinfo WHERE pname = '$pname'";
    // $result2 = mysqli_query($conn,$query2);
    // $row = mysqli_fetch_assoc($result2);
    // print_r($row);
    
    
}


?>