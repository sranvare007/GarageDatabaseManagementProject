<?php
session_start();
include('upuserback.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/carup.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br><br>
        <?php include('error.php'); ?>

        <div class="info">

                
            <form action="upuserinfo.php" method="POST">
                
                <label for name>Customer Name:</label><br>
                <input type="text" name="name"  value="<?php echo $row2['name']; ?>"><br><br>
                <label for vchno>Vehicle Number:</label><br>
                <input type="text" name="vchno" value="<?php echo $row2['vchno']; ?>"><br><br>
                <label for addr>Customer Address:</label><br>
                <input type="text" name="addr" value="<?php echo $row2['addr']; ?>"><br><br>
                <label for phno>Phone Number:</label><br>
                <input type="number" name="phno" value="<?php echo $row2['phno']; ?>"><br><br>
                <input type="submit" name="update" value="Update Info">
            </form>
            <br><br>
        </div>

    </body>
</html>