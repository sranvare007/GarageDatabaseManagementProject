<?php
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$query3 = "SELECT * FROM temp_serv";
$result3 = mysqli_query($conn,$query3);

echo "<table border='1'>
    <tr>
    <th>Service Performed</th>
    <th>Service Charge</th>
    <tr>";
    while($row = mysqli_fetch_assoc($result3))
    {
        $res = $row;
        echo "<tr>";
        echo "<td>" . $res['servtype'] . "</td>";
        echo "<td>" . $res['totcost'] . "</td>";
        echo "<tr>";
    }
    echo "<tr>";
echo "<table>";


?>