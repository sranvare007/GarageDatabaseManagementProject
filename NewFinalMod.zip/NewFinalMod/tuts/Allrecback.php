<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

// $query = "SELECT DISTINCT cust_det.name, cust_det.addr, cust_det.phno, cust_det.vchno, vch_det.comp, vch_det.vmodel ,vch_det.ftype FROM cust_det LEFT OUTER JOIN vch_det ON cust_det.vchno = vch_det.vchno LEFT OUTER JOIN serv_info ON serv_info.vchno = vch_det.vchno";
// $result = mysqli_query($conn,$query);



if(isset($_POST['delete']))
{
    $vch = strtoupper($_POST['vchno']);
    $query1 = "DELETE FROM vch_det WHERE vchno='$vch'";
    $query2 = "DELETE FROM cust_det WHERE vchno='$vch'";
    $result1 = mysqli_query($conn,$query1);
    $result2 = mysqli_query($conn,$query2);
    header('refresh:0; url=Allrec.php');
}

$query = "CALL `jointab`()";
$result = mysqli_query($conn,$query);

?>