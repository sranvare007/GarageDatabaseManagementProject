<?php


$error=array();

$conn = mysqli_connect('localhost','root','');

if(!$conn)
{
    echo 'Error connecting to Server!';
}


if(isset($_POST['log']))
{
    
    $userName = $_POST['username'];
    $passWord = $_POST['password'];
    
    if(empty($userName))
    {
        array_push($error,"Username is Required!");
    }

    if(empty($passWord))
    {
        array_push($error,"Password is Required!");
    }


    if(!mysqli_select_db($conn,'garage'))
    {
        echo 'Database not Availeble!';
    }

    $query = "SELECT * FROM logdet";

    $result = mysqli_query($conn,$query);

    while($row=mysqli_fetch_assoc($result))
    {
        if($userName == $row['userid'] && $passWord == $row['pass'])
        {
            $_SESSION['success'] = 'true';
            header('location: Ulog.php');
        }
        else
        {
            array_push($error,"Invalid Login Credentials!!");
            header("url=login.php");
        }
    }
}
?>