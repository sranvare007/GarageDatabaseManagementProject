<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

if(isset($_POST['update']))
{
    $name = strtoupper($_POST['name']);
    $phno = $_POST['phno'];
    $addr = strtoupper($_POST['addr']);
    $expr = $_POST['exp'];
    $doj = $_POST['doj'];
    $age = $_POST['age'];
    $sal = $_POST['sal'];

    if(empty($name) || empty($phno) || empty($addr) || empty($expr) || empty($doj) || empty($age) || empty($sal))
    {
        array_push($error,"All fields are required!");
    }

    if(count($error) == 0)
    {
        $query = "INSERT INTO emp_data (name,phno,addr,expr,sal,doj,age) VALUES ('$name','$phno','$addr','$expr','$sal','$doj','$age')";
        mysqli_query($conn,$query);
        header('location: Emp.php');
    }

}