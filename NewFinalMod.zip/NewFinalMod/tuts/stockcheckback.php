<?php


$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

$query = "CALL `dispInfo`()";
$result = mysqli_query($conn,$query);

// $query1 = "CALL `selsum`()";
// $result1 = mysqli_query($conn,$query1);


// echo $result1;

?>