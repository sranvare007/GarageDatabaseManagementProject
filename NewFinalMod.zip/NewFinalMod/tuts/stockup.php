<?php
session_start();
include('stockupback.php');
?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style12.css">
        <style>
        
        p
        {
            font-size: 25px;
        }

        .exis, .add
        {
            text-align: center;
            background-color: #ccc;
            border-radius: 10px;
            padding: 10px;
        }
        
        </style>
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br>
        <?php include('error.php');  ?>
        <br><br>



        <div class="add">
            <h1>Add New Part Stock:</h1>
            <br>
            <form action="" method="POST">
                <p>Part Name:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&emsp;&emsp;
                <input type="text" name="pname" placeholder="Enter PartName........"></p>
                <p>Qantity:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&nbsp;
                <input type="number" name="qty" placeholder="Enter Quantity........"></p>
                <p>Price:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                <input type="number" name="price" placeholder="Enter Part Price........"></p>
                <p>Supplier:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                <input type="text" name="supplier" placeholder="Enter Supplier Name........"></p>
                <input type="submit" value="Update" name="upnew">
            </form>
            
        </div>
        

        <br><hr><br>



        <div class="exis">
            <h1>Update Existing Stock:</h1>
            <br>
            <form action="" method="POST">
                <p>Parts Name:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&emsp;&emsp;&emsp;&emsp;
                    <select name="pname">
                        <option value="">---  None  ---</option>
                        <?php
                            while($row = mysqli_fetch_assoc($result))
                            {
                                $pname = $row['pname'];
                                echo '<option value="' . $pname . '">' . $pname . '</option>';
                            }
                        ?>
                    </select>
                </p>

                <p>Quantity to be Added:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
                    <input type="number" name="qty">
                </p>

                <p>New Price:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
                    <input type="number" name="price">
                </p>

                <p>New Supplier:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                    <input type="text" name="supplier">
                </p>


                <input type="submit" value="Update" name="upexis">
            </form>
        </div>
        
    </body>
</html>