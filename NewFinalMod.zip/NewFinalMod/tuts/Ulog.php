<?php
include('search.php');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Drop down menu</title>
    <link rel="stylesheet" type="text/css" href="style/style1.css">
<body bgcolor="#ccf2ff">
    <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
    
    <ul class="x1">
        <li><a href="Ulog.php">User Login</a></li>
        <li><a href="Uinfo.php">User Info Update</a></li>
        <li><a href="service.php">Service Vehicle</a></li>
        <li><a href="Stock.php">Stock Check</a></li>
        <li><a href="Stockup.php">Stock Update</a></li>
        <li><a href="Sinfo.php">Services Made Info</a></li>
        <li><a href="Emp.php">Employee Details</a></li>
        <li><a href="Addemp.php">Add Employee Details</a></li>
        <li><a href="Upemp.php">Update Employee Details</a></li>
        <li><a href="Allrec.php">Show all Customer Info</a></li>
    </ul>

    <br><br><br><br><br>
    <?php include('error.php'); ?>

    <div class="info">
        <form action="Ulog.php" method="POST">
                <label for vchno>Vehicle Number:</label><br>
                <input type="text" name="vchno" placeholder="Enter Vehicle Number...."><br><br>
                <h2><u>OR</u></h2><br>
                <label for phno>Mobile Number:</label><br>
                <input type="number" name="phno" placeholder="Enter Mobile Number...."><br><br><br><br>
                <input type="submit" name="sub" value="Search">
        </form>
        <br><br>
        <p style="font-size:20px;color:white;">New Member? &emsp;<a style="color:blue;" href="Ureg.php">Register Here</a></p>
    </div>

</body>
</html>