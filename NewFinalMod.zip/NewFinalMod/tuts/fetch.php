<?php
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


if(!isset($_SESSION['vchno']))
{
    header('location: Ulog.php');
}

$temp = $_SESSION['vchno'];
$query = "SELECT * FROM cust_det WHERE vchno = '$temp'";

$result = mysqli_query($conn,$query);
$row = mysqli_fetch_assoc($result);

$name = $row['name'];
$phno = $row['phno'];
$add = $row['addr'];
$vchno = $row['vchno'];

if(isset($_POST['upinfo']))
{
    header('location: upuserinfo.php');
}

if(isset($_POST['servch']))
{
    header('location: service.php');
}

if(isset($_POST['cinfo']))
{
    header('location: Sinfo.php');
}
?>