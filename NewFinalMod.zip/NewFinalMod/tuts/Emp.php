<?php
session_start();
include('Empback.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style2.css">
        <style>

            table
            {
                border-style: solid;
                border-width: 2px;
                border-color: blue;
                border-radius: 6px;
                width: 100%;
                text-align: center;
                font-size: 18px;
                border-spacing: 0px; 
            }
            th
            {
                padding: 10px 0px;
                color: white;
                background-color: blue;
            }
            tr:nth-child(even)
            {
                background-color:white;
            }
            tr:nth-child(odd)
            {
                background-color:#ccc;
            }
            #btn
            {
                width: 50%;
                padding: 10px 12px;
                font-size: 15px;
                display: inline;
            }
        </style>
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br><br><br>

        <?php
            echo "<table>
            <tr>
                <th>Employee ID</th>
                <th>Name</th>
                <th>Phone Number</th>
                <th>Address</th>
                <th>Working Experience</th>
                <th>Salary</th>
                <th>Date of Joining</th>
                <th>Age</th>
            </tr>";

            while($row = mysqli_fetch_assoc($result))
            {
                $res = $row;
                echo "<tr>";
                echo "<td>" . $res['emp_id'] . "</td>";
                echo "<td>" . $res['name'] . "</td>";
                echo "<td>" . $res['phno'] . "</td>";
                echo "<td>" . $res['addr'] . "</td>";
                echo "<td>" . $res['expr'] . "</td>";
                echo "<td>" . $res['sal'] . "</td>";
                echo "<td>" . $res['doj'] . "</td>";
                echo "<td>" . $res['age'] . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        ?>
        

    </body>
</html>