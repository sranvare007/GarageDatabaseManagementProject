<style>
.error
{
    text-align: center;
    color:#800000;
    padding: 2px 4px;
    border: 1px solid red;
    width: 50%;
    margin:auto;
    background-color:rgb(255, 26, 26,0.2);
    border-radius:4px;
}
</style>


<?php
if(count($error)>0) : ?>
<div class="error">
    <?php foreach($error as $errors): ?>
    <p><?php echo $errors; ?></p>
    <?php endforeach ?>
</div>

<?php endif ?>