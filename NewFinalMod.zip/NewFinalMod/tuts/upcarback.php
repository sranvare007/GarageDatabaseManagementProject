<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$vchno = $_SESSION['vchno'];

if(isset($_POST['update']))
{

    $ftype = strtoupper($_POST['ftype']);
    $vmodel = strtoupper($_POST['vmodel']);
    $comp = strtoupper($_POST['comp']);

    $query1 = "SELECT * FROM vch_det WHERE vchno='$vchno'";
    $result = mysqli_query($conn,$query1);
    $row = mysqli_fetch_assoc($result);
    
    if(empty($ftype))
    {
        $ftype = $row['ftype'];
    }
    if(empty($vmodel))
    {
        $vmodel = $row['vmodel'];
    }
    if(empty($comp))
    {
        $comp = $row['comp'];
    }
    if(count($error) == 0)
    {
        $query = "UPDATE vch_det SET ftype='$ftype', vmodel='$vmodel', comp='$comp' WHERE vchno='$vchno'";
        if(!mysqli_query($conn,$query))
        {
            echo 'ERROR!';
        }
        else
        {
            header('location: UInfo.php');
        }
    }
}

?>