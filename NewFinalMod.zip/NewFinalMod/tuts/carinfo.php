<?php
session_start();
include('fetch.php');
include('ins.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/stylecinfo.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br>

        <div class="info">
            <h1>CUSTOMER DETAILS:-</h1>
            <div class="left">
                <label for name><font size='5'>Customer Name:</label>
                <?php echo "<font size='5'> $name"; ?><br><br>
                <label for vchno><font size='5'>Vehicle Number:</label>
                <?php echo $vchno; ?>
            </div>

            <div class="right">
                <label for add><font size='5'>Customer Address:</label>
                <?php echo "<font size='5'> $add"; ?><br><br>
                <label for phno><font size='5'>Mobile Number:</label>
                <?php echo $phno; ?>
            </div>
            <br><br><br><br><br>
            <form action="upuserinfo.php" method="POST">
                <input type="submit" value="Update Customer Info" style="padding:5px 5px;width: 500x;">
            </form>
        
        </div>
        <?php include('error.php'); ?>
        
        
        <?php
        if($disable === 0)
        {
            include('carform.php'); 
        }
        else
        {
            include('cardet.php');
        }
        ?>
    </body>
</html>