<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

$query3 = "SELECT * FROM temp";
$result3 = mysqli_query($conn,$query3);

echo "<table border='1'>
    <tr>
    <th>Part Name</th>
    <th>Part Quantity</th>
    <th>Service Charge</th>
    <th>Part Price</th>
    <th>Total Parts Price</th>
    <tr>";
    while($row = mysqli_fetch_assoc($result3))
    {
        $res = $row;
        echo "<tr>";
        echo "<td>" . $res['pname'] . "</td>";
        echo "<td>" . $res['qty'] . "</td>";
        echo "<td>" . $res['servcg'] . "</td>";
        echo "<td>" . $res['price'] . "</td>";
        echo "<td>" . $res['totprice'] . "</td>";
        echo "<tr>";
    }
echo "<table>";


?>