<?php
session_start();
include('partrepback.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style12.css">
        <style>

        table
            {
                border-style: solid;
                border-width: 2px;
                border-color: blue;
                border-radius: 6px;
                width: 100%;
                text-align: center;
                font-size: 18px;
                border-spacing: 0px; 
            }
            th
            {
                padding: 10px 0px;
                color: white;
                background-color: blue;
            }
            tr:nth-child(even)
            {
                background-color:white;
            }
            tr:nth-child(odd)
            {
                background-color:#ccc;
            }

        </style>
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br>

        <div class="info">
            <?php include('error.php') ?>
            <form action="" method="POST">
                <font size='5px'>
                <p>Parts Used:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;
                    <select name="pname" id="pname">
                        <option value="">--- None ---</option>
                        <?php 
                            while($row = mysqli_fetch_assoc($result))
                            {
                                $pname = $row['pname'];
                                echo '<option value="' . $pname . '">' . $pname . '</option>';
                            }
                        ?>
                    </select>
                </p>
                <p>Quantity Used:&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                    <input type="number" name="qty" placeholder="Enter Quantity.....">
                </p>
                <p>Service Charge:&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
                    <input type="number" name="servcg" placeholder="Enter Service charge.....">
                </p>
                <input type="submit" value="Add" name="sub">
                <input type="submit" value="Done" name="done">
            </form>
            <br><br><br><br>
            <?php
                include('partrepbacktab.php');
            ?>
        </div>
    </body>
</html>