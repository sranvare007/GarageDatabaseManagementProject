<div class="data">
    <form action="carinfo.php" method="POST">

        <div class="error">
            Car Info Not Available add Car Info
        </div>
        <font size='5px'>
        <p>Fuel type: &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;
        <select name="ftype">
            <option value=""></option>
            <option value="Petrol">Petrol</option>
            <option value="Diesel">Diesel</option>
            <option value="CNG">CNG</option>
        </select>
        </p>
        <p>Manufacturer Company:&emsp;<input type="text" name="comp" placeholder="Enter Car company......"></p>
        <p>Car Model:&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;<input type="text" name="vmodel" placeholder="Enter Car model......"></p>
        <input type="submit" value="Submit" name="cinfsub">
    
    </form>
</div>