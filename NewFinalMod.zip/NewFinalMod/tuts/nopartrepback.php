<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


if(isset($_POST['sub']))
{
    $type = $_SESSION['type'];
    $vchno = $_SESSION['vchno'];
    $servcg = $_POST['servcg'];
    $query5 = "INSERT INTO serv_info (servtype,parts,totcost,vchno,serv_date) VALUES('$type','','$servcg','$vchno',NOW())";
    mysqli_query($conn,$query5);

    $query6 = "INSERT INTO temp_serv (servtype,totcost) VALUES('$type','$servcg')";
    mysqli_query($conn,$query6);
    header('location: norepbill.php');
}
?>