const pname = document.querySelector('#pname');
const qty = document.querySelector('#qty');
const btn = document.querySelector('#Add');
var list = document.querySelector('.parts');
const servtype = document.querySelector('#servtype');
btn.addEventListener('click',addpart);


function addpart(e)
{
    if(pname.value === '' || qty.value === '')
    {
        alert('Enter Part name and Quantity Both!');
    }
    else
    {
        var row = list.insertRow(0);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        cell1.innerHTML = pname.value;
        cell2.innerHTML = qty.value;
    }
}




















function func()
{
    var x = document.getElementById('mySelect').value;
    if(x == 'fit' || x == 'wash')
    {
        document.querySelector('.part').style.display = 'none';
        console.log('Hidden');
    }
    else
    {
        document.querySelector('.part').style.display = 'block';
    }
}