<?php


$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

if(!isset($_SESSION['vchno']))
{
    header('location: Ulog.php');
}
$vchno = $_SESSION['vchno'];
$query = "SELECT * FROM serv_info where vchno='$vchno'";
$result = mysqli_query($conn,$query);


?>