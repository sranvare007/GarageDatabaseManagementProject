<?php
session_start();
include('fetch.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style2.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br>

        <!-- Displayed User Info -->
        <div class="info">
            <form action="UInfo.php" method="POST">
                <h1>CUSTOMER DETAILS:-</h1>
                <div class="left">
                    <label for name><font size='5'>Customer Name:</label>
                    <?php echo "<font size='5'> $name"; ?><br><br>
                    <label for vchno><font size='5'>Vehicle Number:</label>
                    <?php echo $vchno; ?>
                </div>

                <div class="right">
                    <label for add><font size='5'>Customer Address:</label>
                    <?php echo "<font size='5'> $add"; ?><br><br>
                    <label for phno><font size='5'>Mobile Number:</label>
                    <?php echo $phno; ?>
                </div>
                
            </form>
        </div>

        <!-- Buttons at the bottom -->
        <div class=cinfo>
            <form action="carinfo.php" method="POST">
                <div class="btn1">
                    <input type="submit" value="Show Car Info" name="upcinfo">
                </div>

                <div class="btn2">
                    <input type="submit" value="Car Service Info" name="cinfo">
                </div>

                <div class="btn3">
                    <input type="submit" value="Update User Info" name="upinfo">
                </div>

                <br><br>
                <div class="btn4">
                    <input type="submit" value="Service Vehicle" name="servch" style="width:960px; padding:14px 10px;">
                </div>
            </form>
        </div>
    </body>
</html>