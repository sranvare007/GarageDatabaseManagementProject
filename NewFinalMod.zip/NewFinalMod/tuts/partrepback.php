<?php

$error = array();

$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$query = "SELECT * FROM pinfo";
$result = mysqli_query($conn,$query);

if(isset($_POST['sub']))
{
    $pname = $_POST['pname'];
    $qty = $_POST['qty'];
    $servcg = $_POST['servcg'];

    $query1 = "SELECT * FROM pinfo WHERE pname='$pname'";
    $result1 = mysqli_query($conn,$query1);
    $row = mysqli_fetch_assoc($result1);

    if($qty>$row['qty'])
    {
        array_push($error,"Insuffient Stock Availeble!");
    }
    else
    {
        $query3 = "UPDATE pinfo SET qty = qty - '$qty' WHERE pname='$pname'";
        mysqli_query($conn,$query3);
    }
    
    $price = $row['price'];
    $totprice = $price * $qty;
    

    if(empty($pname) || empty($qty))
    {
        array_push($error,"Enter Part name and quantity both");
    }
    else
    {
        if(count($error) == 0)
        {
            $query2 = "INSERT INTO temp (pname,qty,servcg,price,totprice) VALUES ('$pname','$qty','$servcg','$price','$totprice')";
            if(!mysqli_query($conn,$query2))
            {
                array_push($error,"Part has already been added!");
            }
        }
    }
}

if(isset($_POST['done']))
{
    header('location: bill.php');
}
