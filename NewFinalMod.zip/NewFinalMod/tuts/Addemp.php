<?php
session_start();
include('Addempback.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/carup.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br><br>
        <?php include('error.php'); ?>

        <div class="info">

                
            <form action="" method="POST">
                
                <label for name>Employee Name:</label><br>
                <input type="text" name="name" placeholder="Enter Employee Name...."><br><br>
                <label for phno>Phone Number:</label><br>
                <input type="number" name="phno" placeholder="Enter Phone Number...."><br><br>
                <label for addr>Address:</label><br>
                <input type="text" name="addr" placeholder="Enter Address...."><br><br>
                <label for exp>Work Experience:</label><br>
                <input type="number" name="exp" placeholder="Enter Work Experience...."><br><br>

                <label for sal>Salary:</label><br>
                <input type="number" name="sal" placeholder="Enter Salary...."><br><br>

                <label for doj>Date of Joining:</label><br>
                <input type="date" name="doj"><br><br>
                <label for age>Age:</label><br>
                <input type="number" name="age" placeholder="Enter Age...."><br><br>
                <input type="submit" name="update" value="Add Info">
            </form>
            <br><br>
        </div>

    </body>
</html>