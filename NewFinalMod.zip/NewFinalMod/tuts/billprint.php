<?php
session_start();
include('fetch.php');
include('billprintback.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Bill</title>
        <link rel="stylesheet" type="text/css" href="style/style2.css">
        <style>

        table
            {
                border-style: solid;
                border-width: 2px;
                border-color: blue;
                border-radius: 6px;
                width: 100%;
                text-align: center;
                font-size: 18px;
                border-spacing: 0px; 
            }
            th
            {
                padding: 10px 0px;
                color: white;
                background-color: blue;
            }
            tr:nth-child(even)
            {
                background-color:white;
            }
            tr:nth-child(odd)
            {
                background-color:#ccc;
            }

            .bill
            {
                border: 3px solid black;
                padding: 10px;
            }
            h1>p
            {
                float:right;
                font-size: 20px;
            }
            p
            {
                display:inline;
            }
            .footer
            {
                padding: 15px 0px;
                background-color: blue;
                border-radius: 6px;
                color: white;
                text-align:center;
            }
            #printbtn
            {
                width: 100%; 
            }
            .home
            {
                text-align: center;
            }
            @media print{
            .no-print
            {
                display: none !important;
            }
            }
            .lft
            {
                float: left;
                display:inline;
                clear: left;
            }
            .rgt
            {
                float: right;
                display:inline;
                clear:right;
            }

        </style>
    </head>
    <body bgcolor="#ccf2ff">
    <div class="bill">
        <h1 id="a1">MAYUR CAR SERVICE CENTER<p>Contact Info.  9272724877</p></h1>
        <br><br><br>
        <p class="lft">Customer Name: <?php echo $name ?></p>
        <p class="rgt">Customer Phone Number: <?php echo $phno ?></p><br><br>
        <p class="lft">Vehicle Number: <?php echo $vchno ?></p>
        <p class="rgt">Address: <?php echo $add ?></p><br><br>
       
        <?php
            echo "<table border='1'>
            <tr>
            <th>Part Name</th>
            <th>Part Quantity</th>
            <th>Service Charge</th>
            <th>Part Price</th>
            <th>Total Parts Price</th>
            <tr>";
            while($row = mysqli_fetch_assoc($result3))
            {
                $res = $row;
                echo "<tr>";
                echo "<td>" . $res['pname'] . "</td>";
                echo "<td>" . $res['qty'] . "</td>";
                echo "<td>" . $res['servcg'] . "</td>";
                echo "<td>" . $res['price'] . "</td>";
                echo "<td>" . $res['totprice'] . "</td>";
                echo "<tr>";
            }
            echo "<tr>";
            echo "<td colspan='4'>Total Price</td>";
            echo "<td>" . $resu . "</td>";
            echo "<tr>";
        echo "<table>";
        ?>
        <br><br>
        <div class="footer">
            Address:-   Near Hinjewadi phata, Phase-3,Hinjewadi, Maharashtra
        </div>
    </div>
    <br><br>
    <input type="submit" value="Print" id="printbtn" class="no-print" onclick=window.print()>
    <br><br><br>
    <div class="home">
        <form action="Ulog.php">
            <input type="submit" value="Home" name="home" id="homebtn" class="no-print">
        </form>
    </div>
    </body>
</html>