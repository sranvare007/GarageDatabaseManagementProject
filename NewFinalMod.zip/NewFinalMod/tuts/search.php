<?php
$error=array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(isset($_POST['sub']))
{
    $vchno = strtoupper($_POST['vchno']);
    $phno = strtoupper($_POST['phno']);

    if(empty($vchno) && empty($phno))
    {
        array_push($error,"Both Fields cannot be empty");
        
    }

    if(count($error) == 0)
    {
        if(!empty($vchno) && !empty($phno))
        {
            $query1 = "SELECT * FROM cust_det WHERE vchno='$vchno' AND phno='$phno'";
            $result1 = mysqli_query($conn,$query1);
            if(mysqli_num_rows($result1) == 1)
            {
                session_start();
                $_SESSION['vchno'] = $vchno;
                header('location: UInfo.php');
            }
            else
            {
                array_push($error,"Invalid Combination of Vehicle number and Phone Number");
            }
        }
        else
        {
            $query = "SELECT * FROM cust_det WHERE vchno='$vchno' OR phno='$phno'";
            $result = mysqli_query($conn,$query);
            if(mysqli_num_rows($result) == 1)
            {
                session_start();
                if(empty($vchno))
                {
                    $row = mysqli_fetch_assoc($result);
                    $_SESSION['vchno'] = $row['vchno'];
                    echo $_SESSION['vchno'];
                    header('location: UInfo.php');
                }
                else
                {
                    session_start();
                    $_SESSION['vchno'] = $vchno;
                    header('location: UInfo.php');
                }
            }
            else
            {
                array_push($error,"Record does not exist please Register instead!");
            }
        }    

    }




}

?>