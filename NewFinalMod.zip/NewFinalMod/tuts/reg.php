<?php

$error=array();

$conn = mysqli_connect('localhost','root','');

if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


if(isset($_POST['subs']))
{
    $vchno = strtoupper($_POST['vchno']);
    $phno = strtoupper($_POST['phno']);
    $name = strtoupper($_POST['name']);
    $add = strtoupper($_POST['add']);

    if(!mysqli_select_db($conn,'garage'))
    {
        echo 'Database not availeble';
    }
    
    if(empty($vchno) && empty($phno))
    {
        array_push($error,"Both Vehicle Number and Phone number cannot be empty");
    }

    if(count($error) == 0)
    {
        $query = "SELECT * FROM cust_det WHERE vchno='$vchno' OR phno='$phno'";
        $result = mysqli_query($conn,$query);

        if(mysqli_num_rows($result) == 1)
        {
            array_push($error,"Record Already Exists! Login Instead!");
        }
        else
        {
            $query1 = "INSERT INTO cust_det (name,addr,vchno,phno) VALUES('$name','$add','$vchno','$phno')";
            mysqli_query($conn,$query1);
            header('location: Ulog.php');
        }


        // while($row=mysqli_fetch_assoc($result))
        // {
        //     if($vchno === $row['vchno'] || $phno === $row['phno'])
        //     {  
        //         array_push($error,"Record already Exists!Login instead.");
        //     }
        //     else
        //     {
        //         $query1 = "INSERT INTO cust_det (name,addr,vchno,phno) VALUES('$name','$add','$vchno','$phno')";
        //         mysqli_query($conn,$query1);
        //         header('location: Ulog.php');
        //     }
        // }
    }

}











?>