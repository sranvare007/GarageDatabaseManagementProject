<?php

$error=array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}

if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

$temp = $_SESSION['vchno'];
$query1 = "SELECT * FROM vch_det where vchno = '$temp'";

$result = mysqli_query($conn,$query1);
$row = mysqli_fetch_assoc($result);

$ftype = $row['ftype'];
$vmodel = $row['vmodel'];
$comp = $row['comp'];

$disable;
if(mysqli_num_rows($result) == 1)
{
    $disable = 1;
    echo 'Disbled = ' . $disable; 
}
else
{
    $disable = 0;
}
 if(isset($_POST['cinfsub']))
{
    $vchno = strtoupper($_SESSION['vchno']);
    $ftype = strtoupper($_POST['ftype']);
    $vmodel = strtoupper($_POST['vmodel']);
    $comp = strtoupper($_POST['comp']);

    if(empty($vmodel) || empty($comp) || empty($ftype))
    {
        array_push($error,"All fields are required!");
    }

    if(count($error) == 0)
    {
        $query = "INSERT INTO vch_det (vchno,ftype,vmodel,comp) VALUES ('$vchno','$ftype','$vmodel','$comp')";

        mysqli_query($conn,$query);
        header('location: Uinfo.php');
    }
}

?>