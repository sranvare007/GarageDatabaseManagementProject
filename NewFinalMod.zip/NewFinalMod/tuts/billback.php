<?php
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$query3 = "SELECT * FROM temp";
$result3 = mysqli_query($conn,$query3);

$query4 = "SELECT SUM(totprice) + SUM(servcg) FROM temp";
$result4 = mysqli_query($conn,$query4);
$row = mysqli_fetch_assoc($result4);
$resu = $row['SUM(totprice) + SUM(servcg)'];






$type = $_SESSION['type'];
$vchno = $_SESSION['vchno'];

$query2 = "SELECT * FROM temp";
$result2 = mysqli_query($conn,$query2);

$str = '';
while($row2 = mysqli_fetch_assoc($result2))
{
    $temp = $row2['pname'];
    if(empty($str))
    {
        $str = $str . $temp;
    }
    else
    {
        $str = $str . ',' . $temp;
    }
}

$query5 = "INSERT INTO serv_info (servtype,parts,totcost,vchno,serv_date) VALUES('$type','$str','$resu','$vchno',NOW())";
mysqli_query($conn,$query5);


?>