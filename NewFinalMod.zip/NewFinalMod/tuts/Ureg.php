<?php
session_start();
include('reg.php');
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style1.css">
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br><br>
        <?php include('error.php'); ?>

        <div class="info">
            <form action="Ureg.php" method="POST">
                <label for name>Customer Name:</label><br>
                <input type="text" name="name" placeholder="Enter Cutsomer Name...."><br><br>
                <label for name>Vehicle Number</label><br>
                <input type="text" name="vchno" placeholder="Enter Vehicle Number...."><br><br>
                <label for name>Customer Address:</label><br>
                <input type="text" name="add" placeholder="Enter Cutsomer Address...."><br><br>
                <label for phno>Mobile Number:</label><br>
                <input type="number" name="phno" placeholder="Enter Mobile Number...."><br><br>
                <input type="submit" name="subs" value="Register">
            </form>
            <br><br>
            <p style="font-size:20px;color:white;">Already a Member? &emsp;<a style="color:blue;" href="Ulog.php">Login Here</a></p>
        </div>

    </body>
</html>