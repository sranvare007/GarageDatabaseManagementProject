<?php
session_start();
include('billback.php')
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>User Registration</title>
        <link rel="stylesheet" type="text/css" href="style/style12.css">
        <style>

        table
            {
                border-style: solid;
                border-width: 2px;
                border-color: blue;
                border-radius: 6px;
                width: 100%;
                text-align: center;
                font-size: 18px;
                border-spacing: 0px; 
            }
            th
            {
                padding: 10px 0px;
                color: white;
                background-color: blue;
            }
            tr:nth-child(even)
            {
                background-color:white;
            }
            tr:nth-child(odd)
            {
                background-color:#ccc;
            }

            #printbtn
            {
                width: 100%;
                box-sizing: border-box;
            }
        </style>
    </head>
    <body bgcolor="#ccf2ff">
        <h1 id="a1">MAYUR CAR SERVICE CENTER</h1>
        
        <ul class="x1">
            <li><a href="Ulog.php">User Login</a></li>
            <li><a href="Uinfo.php">User Info Update</a></li>
            <li><a href="service.php">Service Vehicle</a></li>
            <li><a href="Stock.php">Stock Check</a></li>
            <li><a href="Stockup.php">Stock Update</a></li>
            <li><a href="Sinfo.php">Services Made Info</a></li>
            <li><a href="Emp.php">Employee Details</a></li>
            <li><a href="Addemp.php">Add Employee Details</a></li>
            <li><a href="Upemp.php">Update Employee Details</a></li>
            <li><a href="Allrec.php">Show all Customer Info</a></li>
        </ul>

        <br><br><br><br><br><br><br>

        <?php
            echo "<table border='1'>
            <tr>
            <th>Part Name</th>
            <th>Part Quantity</th>
            <th>Service Charge</th>
            <th>Part Price</th>
            <th>Total Parts Price</th>
            <tr>";
            while($row = mysqli_fetch_assoc($result3))
            {
                $res = $row;
                echo "<tr>";
                echo "<td>" . $res['pname'] . "</td>";
                echo "<td>" . $res['qty'] . "</td>";
                echo "<td>" . $res['servcg'] . "</td>";
                echo "<td>" . $res['price'] . "</td>";
                echo "<td>" . $res['totprice'] . "</td>";
                echo "<tr>";
            }
            echo "<tr>";
            echo "<td colspan='4'>Total Price</td>";
            echo "<td>" . $resu . "</td>";
            echo "<tr>";
        echo "<table>";
        ?>
        <br><br><br>
        <form action="billprint.php" method="POST">
        <input type="submit" name="print" value="Confirm" id="printbtn">
        </form>
    </body>
</html>