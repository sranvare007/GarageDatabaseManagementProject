<?php


$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}

if(isset($_POST['sub']))
{
    $query2 = "CALL `critstock`()";
    $result2 = mysqli_query($conn,$query2);

    echo "<table border='1'>
    <tr>
    <th>Part Name</th>
    <th>Quantity Left</th>
    <tr>";

    while($row2 = mysqli_fetch_assoc($result2))
    {
        $res = $row2;
        echo "<tr>";
        echo "<td>" . $res['part'] . "</td>";
        echo "<td>" . $res['qnty'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
}
?>