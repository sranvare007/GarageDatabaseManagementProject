<?php

$error = array();
$conn = mysqli_connect('localhost','root','');
if(!$conn)
{
    echo 'Error connecting to Server!';
}

if(!mysqli_select_db($conn,'garage'))
{
    echo 'Database not available';
}


if(!isset($_SESSION['success']))
{
    header('location: login.php');
}


$temp2 = $_SESSION['vchno'];
$query2 = "SELECT * FROM cust_det WHERE vchno='$temp2'";
$result2 = mysqli_query($conn,$query2);
$row2 = mysqli_fetch_assoc($result2);


if(isset($_POST['update']))
{

    $temp = $_SESSION['vchno'];
    $name = strtoupper($_POST['name']);
    $addr = strtoupper($_POST['addr']);
    $phno = strtoupper($_POST['phno']);
    $vchno = strtoupper($_POST['vchno']);

    $query1 = "SELECT * FROM cust_det WHERE vchno='$temp'";
    $result = mysqli_query($conn,$query1);
    $row = mysqli_fetch_assoc($result);

    

    if(count($error) == 0)
    {
        $query = "UPDATE cust_det SET name='$name',addr='$addr',vchno='$vchno',phno='$phno' WHERE vchno='$temp'";
        if($temp != $vchno)
        {
            $query2 = "DELETE FROM vch_det WHERE vchno='$temp'";
            mysqli_query($conn,$query2);
            $_SESSION['vchno'] = $vchno;
        }
        if(!mysqli_query($conn,$query))
        {
            echo 'ERROR!';
        }
        else
        {
            header('location: UInfo.php');
        }
    }
}

?>