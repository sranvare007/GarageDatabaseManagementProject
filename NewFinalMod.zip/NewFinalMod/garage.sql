-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2018 at 10:04 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garage`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `critstock` ()  NO SQL
BEGIN
	DECLARE part VARCHAR(30);
    DECLARE qnty INT;
    DECLARE exit_loop BOOLEAN DEFAULT FALSE;
    DECLARE stockcursor CURSOR FOR SELECT pname, qty FROM pinfo;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET exit_loop = TRUE;
    OPEN stockcursor;
    stock_loop: LOOP
    	FETCH FROM stockcursor INTO part,qnty;
    	IF exit_loop THEN
        	LEAVE stock_loop;
        END IF;
        IF qnty<5 THEN
       		SELECT part, qnty;
    	END IF;
    END LOOP stock_loop;
    CLOSE stockcursor;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `dispInfo` ()  NO SQL
SELECT * FROM pinfo ORDER BY qty$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `jointab` ()  NO SQL
BEGIN
SELECT DISTINCT cust_det.name, cust_det.addr, cust_det.phno, cust_det.vchno, vch_det.comp, vch_det.vmodel ,vch_det.ftype FROM cust_det LEFT OUTER JOIN vch_det ON cust_det.vchno = vch_det.vchno LEFT OUTER JOIN serv_info ON serv_info.vchno = vch_det.vchno;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `selsum` ()  NO SQL
SELECT SUM( qty * price )
FROM pinfo$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `custaudit`
--

CREATE TABLE `custaudit` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `vchno` varchar(10) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `action` varchar(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `custaudit`
--

INSERT INTO `custaudit` (`id`, `name`, `addr`, `vchno`, `phno`, `action`, `date`) VALUES
(4, 'SURAJ SUNIL RANVARE', 'DUBAI', 'MH14CQ5229', 7057296203, 'UPDATE', '2018-10-04'),
(5, 'AKASH NALWADE', 'DUBAI', 'MH12AC8990', 9657280153, 'UPDATE', '2018-10-04'),
(6, 'AKASH NALWADE', 'BAPDEVNAGAR', 'MH12AC8990', 9657280153, 'UPDATE', '2018-10-04'),
(7, 'SURAJ SUNIL RANVARE', 'INDIA', 'MH14CQ5229', 7057296203, 'UPDATE', '2018-10-04'),
(8, 'SURAJ SUNIL RANVARE', 'PORTUGAL', 'MH14CQ5229', 7057296203, 'UPDATE', '2018-10-06'),
(9, 'SURAJ SUNIL RANVARE', 'USA', 'MH14CQ5229', 7057296203, 'UPDATE', '2018-10-06'),
(10, 'SURAJ SUNIL RANVARE', 'INDIA', 'MH14CQ5229', 7057296203, 'UPDATE', '2018-10-06'),
(11, 'ABHISHEK SINGH', 'ELLORA', 'MH12AS4848', 8546201356, 'DELETE', '2018-10-06'),
(12, 'AKASH NALWADE', 'PORTUGAL', 'MH12AC8990', 9657280153, 'DELETE', '2018-10-06'),
(13, 'SUMIT KOLHE', 'DUTTANAGAR,DEHUROAD', 'MH10AE8997', 8456952130, 'DELETE', '2018-10-06'),
(14, 'AKASH NALWADE', 'DEHUROAD', 'MH12AC8990', 8754126589, 'INSERT', '2018-10-06'),
(15, 'AKASH NALWADE', 'DEHUROAD', 'MH12AC8990', 8754126589, 'DELETE', '2018-10-06'),
(16, 'SURAJ SUNIL RANVARE', 'INDIA', 'MH14CQ5121', 7057296203, 'UPDATE', '2018-10-06'),
(17, 'AKASH NALWADE', 'BAPDEVNAGAR', 'MH12AC8990', 7852155630, 'INSERT', '2018-10-06'),
(18, 'ABHISHEK SINGH', 'ELLORA', 'MH10AE8997', 854120150, 'INSERT', '2018-10-06'),
(19, 'ABHISHEK SINGH', 'ELLORA', 'MH10AE8997', 854120150, 'DELETE', '2018-10-06'),
(20, 'AKASH NALWADE', 'BAPDEVNAGAR', 'MH12AC8990', 7852155630, 'DELETE', '2018-10-06'),
(21, 'SURAJ SUNIL RANVARE', 'INDIA', 'MH14CQ5229', 7057296203, 'DELETE', '2018-10-06'),
(22, 'SURAJ RANVARE', 'DEHUROAD', 'MH14CQ5229', 7057296203, 'INSERT', '2018-10-06'),
(23, 'SURAJ RANVARE', 'DEHUROAD', 'MH14CQ5229', 7057296203, 'DELETE', '2018-10-06');

-- --------------------------------------------------------

--
-- Table structure for table `cust_det`
--

CREATE TABLE `cust_det` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `addr` text,
  `vchno` varchar(10) NOT NULL,
  `phno` bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `cust_det`
--
DELIMITER $$
CREATE TRIGGER `auditInfo` BEFORE UPDATE ON `cust_det` FOR EACH ROW INSERT INTO custaudit VALUES (null,OLD.name,OLD.addr,OLD.vchno,OLD.phno,'UPDATE',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `auditInfo1` BEFORE DELETE ON `cust_det` FOR EACH ROW INSERT INTO custaudit VALUES (null,OLD.name,OLD.addr,OLD.vchno,OLD.phno,'DELETE',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `auditInfo2` AFTER INSERT ON `cust_det` FOR EACH ROW INSERT INTO custaudit VALUES (null,NEW.name,NEW.addr,NEW.vchno,NEW.phno,'INSERT',NOW())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `emp_data`
--

CREATE TABLE `emp_data` (
  `emp_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phno` bigint(20) NOT NULL,
  `addr` varchar(200) NOT NULL,
  `expr` int(11) NOT NULL,
  `sal` int(11) NOT NULL,
  `doj` date NOT NULL,
  `age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emp_data`
--

INSERT INTO `emp_data` (`emp_id`, `name`, `phno`, `addr`, `expr`, `sal`, `doj`, `age`) VALUES
(6, 'AKASH NALWADE', 8864499658, 'DUBAI', 5, 100000, '1990-10-10', 52),
(7, 'SUMIT KOLHE', 9965728412, 'ITALY', 5, 125000, '2010-10-10', 31),
(8, 'ABHISHEK SINGH', 8521479635, 'PORTUGAL', 6, 180000, '2000-02-22', 41);

-- --------------------------------------------------------

--
-- Table structure for table `logdet`
--

CREATE TABLE `logdet` (
  `userid` varchar(10) NOT NULL,
  `pass` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logdet`
--

INSERT INTO `logdet` (`userid`, `pass`) VALUES
('suraj', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `pinfo`
--

CREATE TABLE `pinfo` (
  `pid` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `supplier` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pinfo`
--

INSERT INTO `pinfo` (`pid`, `pname`, `qty`, `price`, `supplier`) VALUES
(14, 'WHEEL', 71, 1000, 'MICHELIN'),
(15, 'RIM', 4, 1000, 'MICHELIN'),
(16, 'ENGINE', 224, 100000, 'GREG'),
(17, 'PAINT', 99, 500, 'ASERA');

-- --------------------------------------------------------

--
-- Table structure for table `serv_info`
--

CREATE TABLE `serv_info` (
  `servid` int(11) NOT NULL,
  `servtype` varchar(50) NOT NULL,
  `parts` text NOT NULL,
  `totcost` int(11) NOT NULL,
  `vchno` varchar(10) NOT NULL,
  `serv_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `serv_info`
--

INSERT INTO `serv_info` (`servid`, `servtype`, `parts`, `totcost`, `vchno`, `serv_date`) VALUES
(26, 'FULL', 'RIM,WHEEL', 54112, 'MH14CQ5229', '2018-10-06'),
(28, 'FIT', '', 150, 'MH14CQ5229', '2018-10-06'),
(29, 'FIT', '', 160, 'MH12AC8990', '2018-10-06');

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `pname` varchar(30) NOT NULL,
  `qty` int(11) NOT NULL,
  `servcg` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `totprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp`
--

INSERT INTO `temp` (`pname`, `qty`, `servcg`, `price`, `totprice`) VALUES
('RIM', 4, 45647, 1000, 4000),
('WHEEL', 4, 465, 1000, 4000);

-- --------------------------------------------------------

--
-- Table structure for table `temp_serv`
--

CREATE TABLE `temp_serv` (
  `servtype` varchar(50) NOT NULL,
  `totcost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_serv`
--

INSERT INTO `temp_serv` (`servtype`, `totcost`) VALUES
('FIT', 160);

-- --------------------------------------------------------

--
-- Table structure for table `vchaudit`
--

CREATE TABLE `vchaudit` (
  `id` int(11) NOT NULL,
  `vchno` varchar(10) NOT NULL,
  `ftype` varchar(50) NOT NULL,
  `vmodel` varchar(50) NOT NULL,
  `comp` varchar(100) NOT NULL,
  `action` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vchaudit`
--

INSERT INTO `vchaudit` (`id`, `vchno`, `ftype`, `vmodel`, `comp`, `action`, `date`) VALUES
(3, 'MH12AC8990', 'PETROL', 'SCLASS', 'MERCEEDES', 'UPDATE', '2018-10-04'),
(4, 'MH12AC8990', 'DIESEL', 'SCLASS', 'MERCEEDES', 'UPDATE', '2018-10-04'),
(5, 'MH14CQ5229', 'CNG', 'AVENDATOR', 'LAMBORGHINI', 'DELETE', '2018-10-06'),
(6, 'MH14CQ5121', 'DIESEL', 'GALLARDO', 'LAMBORGHINI', 'INSERT', '2018-10-06'),
(7, 'MH12AC8990', 'CNG', 'SCLASS', 'MERCEEDES', 'DELETE', '2018-10-06'),
(8, 'MH14CQ5121', 'DIESEL', 'GALLARDO', 'LAMBORGHINI', 'DELETE', '2018-10-06'),
(9, 'MH14CQ5229', 'PETROL', 'GALLARDO', 'LAMBORGHINI', 'INSERT', '2018-10-06'),
(10, 'MH12AC8990', 'PETROL', 'SCLASS', 'MERCEEDES', 'INSERT', '2018-10-06'),
(11, 'MH12AC8990', 'PETROL', 'SCLASS', 'MERCEEDES', 'DELETE', '2018-10-06'),
(12, 'MH14CQ5229', 'PETROL', 'GALLARDO', 'LAMBORGHINI', 'DELETE', '2018-10-06'),
(13, 'MH14CQ5229', 'PETROL', 'GALLARDO', 'LAMBORGHINI', 'INSERT', '2018-10-06'),
(14, 'MH14CQ5229', 'PETROL', 'GALLARDO', 'LAMBORGHINI', 'DELETE', '2018-10-06');

-- --------------------------------------------------------

--
-- Table structure for table `vch_det`
--

CREATE TABLE `vch_det` (
  `vchno` varchar(10) NOT NULL,
  `ftype` varchar(10) NOT NULL,
  `vmodel` varchar(20) NOT NULL,
  `comp` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `vch_det`
--
DELIMITER $$
CREATE TRIGGER `vchaudit` BEFORE UPDATE ON `vch_det` FOR EACH ROW INSERT INTO vchaudit VALUES (null,OLD.vchno,OLD.ftype,OLD.vmodel,OLD.comp,'UPDATE',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `vchaudit1` BEFORE DELETE ON `vch_det` FOR EACH ROW INSERT INTO vchaudit VALUES (null,OLD.vchno,OLD.ftype,OLD.vmodel,OLD.comp,'DELETE',NOW())
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `vchaudit2` AFTER INSERT ON `vch_det` FOR EACH ROW INSERT INTO vchaudit VALUES (null,NEW.vchno,NEW.ftype,NEW.vmodel,NEW.comp,'INSERT',NOW())
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `custaudit`
--
ALTER TABLE `custaudit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_det`
--
ALTER TABLE `cust_det`
  ADD PRIMARY KEY (`vchno`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `phno` (`phno`);

--
-- Indexes for table `emp_data`
--
ALTER TABLE `emp_data`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `logdet`
--
ALTER TABLE `logdet`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `pinfo`
--
ALTER TABLE `pinfo`
  ADD UNIQUE KEY `pid` (`pid`);

--
-- Indexes for table `serv_info`
--
ALTER TABLE `serv_info`
  ADD PRIMARY KEY (`servid`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`pname`);

--
-- Indexes for table `vchaudit`
--
ALTER TABLE `vchaudit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vch_det`
--
ALTER TABLE `vch_det`
  ADD PRIMARY KEY (`vchno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `custaudit`
--
ALTER TABLE `custaudit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `cust_det`
--
ALTER TABLE `cust_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `emp_data`
--
ALTER TABLE `emp_data`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pinfo`
--
ALTER TABLE `pinfo`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `serv_info`
--
ALTER TABLE `serv_info`
  MODIFY `servid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `vchaudit`
--
ALTER TABLE `vchaudit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
